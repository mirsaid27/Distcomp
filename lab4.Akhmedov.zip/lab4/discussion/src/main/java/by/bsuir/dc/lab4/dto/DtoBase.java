package by.bsuir.dc.lab4.dto;

public interface DtoBase {
    Long id = 0L;

    Long getId();
}
